<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

<?php

$string = "Hello student do you like the class";

echo strlen($string);

echo "<br>";

echo strtoupper($string);

echo "<br>";

echo strtolower($string);



    
?>

</body>
</html>