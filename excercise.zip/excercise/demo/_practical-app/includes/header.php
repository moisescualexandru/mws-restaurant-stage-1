
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Practical PHP App</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>
</head>
<body id="home">
	<div class="container">
		<header class="row">
			
			<h1 class="text-center"><?php  getTitle(); ?></h1>

		</header>