
</section><!--CONTENT-->
	</div><!--Container-->
	
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
	<script src="js/myscript.js"></script>
</body>
</html>