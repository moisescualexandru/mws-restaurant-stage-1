<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body> 
 
<?php 

/* This function below displays text

this is multiline comment */

// One line comment
    
echo "Hello Student";  
    
    
?>  
   

</body>
</html>


