<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php 
    
$name = 'Edwin';
$number = 100;
$Number_List = 100.5;
//$num-ber= 400;
//$0number = 500;
$NUMBER = 100;
$NUMBeR = 100;
echo $name . " " . $NUMBeR;

$name = "<h1> HELLO</h1>";

echo $name;

    
?>



</body>
</html>